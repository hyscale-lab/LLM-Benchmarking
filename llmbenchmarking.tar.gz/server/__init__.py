# server/__init__.py

from .server import app

__all__ = ["app"]
