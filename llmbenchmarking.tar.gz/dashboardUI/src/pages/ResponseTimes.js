import AppMetricsPage from "../sections/@dashboard/app/AppMetricsPage";

export default function ResponseTimes() {
  return <AppMetricsPage metricType="response_times" title="Response Times Metrics" metricName="Response Times" min={500} />;
}
